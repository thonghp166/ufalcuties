<?php $__env->startSection('content'); ?>

<div class="content">
    <div class="resetbox">
        <div class="container">
            <div class="row">
                <div class="col-6">
                    <h2>Bạn gặp trở ngại khi đăng nhập ?</h2>
                    <p class="resettitle">Nhập email của bạn để bắt đầu</p>
                    <form method="POST" action="<?php echo e(route('password.email')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <fieldset class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required placeholder="Nhập email của bạn vào đây">
                            <?php if($errors->has('email')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </fieldset>
                        <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Gửi email lấy lại mật khẩu</button>
                    </form>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" style="margin-top: 30px;">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-2"></div>
                <div class="col-4 detail">
                    <div class="row">
                        <div class="col-3">
                            <div class="text-right">
                                <i class="fas fa-user-friends icon"></i>                 
                            </div>
                        </div>
                        <div class="col-9">
                            <p>Sau khi bấm gửi, thông tin đặt lại mật khẩu sẽ được chuyển vào hòm thư email của bạn, vào email để lấy thông tin này</p>  
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="copyright">
    <div class="container">
        <div class="row">
            <div class="col-6">
                <div class="float-left">
                    Copyright © 2019 Sharon Team. All rights reserved.        
                </div>
            </div>
            <div class="col-6">
                <div class="float-right">
                    <img src="<?php echo e(URL::asset('images/vietnam.png')); ?>" alt="" class="img-fluid flag">
                    <p class="vietnam">Việt Nam</p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="top">
  <i class="fas fa-arrow-circle-up"></i>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>