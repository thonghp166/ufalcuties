<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/all.css')); ?>">
</head>
<body>

    <div class="menubar">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark mt-3" id="bar">
          <a class="navbar-brand" href="<?php echo e(route('home')); ?>" id="logo">
              <img src="<?php echo e(URL::asset('images/logo-outline.png')); ?>" alt="Logo u-Faculties">
              u-Faculties
          </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
        
          <div class="collapse navbar-collapse text-center" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto mr-5">
              <li class="nav-item active">
                <a class="nav-link" href="<?php echo e(route('home')); ?>">Trang chủ<span class="sr-only">(current)</span></a>
              </li>
                         
             <?php if(Auth::guest()): ?>
                  <li class="nav-item">
                        <a class="nav-link loginbutton" href="<?php echo e(route('login')); ?>">Đăng nhập</a>
                  </li>
              <?php else: ?>
                <?php if(Auth::user()->level == 1): ?>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin.home')); ?>" >Quản lý thông tin</a>
                  </li> 
                <?php endif; ?>  
                  <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="font-weight: bold; font-style: italic;">
                      Xin chào <?php echo e(Auth::user()->username); ?> !
                    </a>
                    <div class="dropdown-menu text-right" aria-labelledby="navbarDropdown">
                      <a class="dropdown-item" href="<?php echo e(route('staff.edit',['id' => Auth::user()->staff->id])); ?>">Chỉnh sửa thông tin cá nhân</a>
                      <div class="dropdown-divider"></div>
                      <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        Đăng xuất
                      </a>
                      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo e(csrf_field()); ?>

                      </form>
                    </div>
                  </li>
                <?php endif; ?>
            </ul>
            
          </div>
        </nav>

        <?php echo $__env->yieldContent('banner'); ?>
  </div>

  <?php echo $__env->yieldContent('content'); ?>
    
    
  <script type="text/javascript" src="<?php echo e(URL::asset('js/jquery-3.3.1.slim.min.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(URL::asset('js/popper.min.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(URL::asset('js/bootstrap.min.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(URL::asset('js/welcome.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(URL::asset('js/jquery-3.4.1.min.js')); ?>"></script>           
</body>
</html>